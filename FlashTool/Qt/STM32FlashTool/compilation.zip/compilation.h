#ifndef COMPILATION_H
#define COMPILATION_H

#include <QObject>
#include <thread>

class QProcess;

class Compilation : public QObject
{
    Q_OBJECT
public:
    explicit Compilation(QObject *parent = nullptr);
    void startCompilation(QString memory);
    QString& compileText();


public slots:
    void setCompileText(QString &compileText);
    void readSubProcess();
    void readError();

signals:
    void compileTextChanged(QString& var);

private:
    std::thread *m_CompileThread;
    QProcess *m_Process;
    QString m_CompileText;



};

#endif // COMPILATION_H
