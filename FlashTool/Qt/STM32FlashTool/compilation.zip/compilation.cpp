#include "compilation.h"
#include <stdlib.h>
#include <QtDebug>
#include <QProcess>
#include <QDir>
#include <qtextcodec.h>

Compilation::Compilation(QObject *parent) : QObject(parent), m_CompileThread(nullptr), m_CompileText("894984984")
{

}

/*static*/ void Compilation::startCompilation(QString memory)
{
        qDebug() << "TEST";
        QString test = "HALLO";
        m_CompileText.append(test);
        emit compileTextChanged(m_CompileText);

          /*  QDir tmpDir("tmp");
           if(tmpDir.exists())
                tmpDir.removeRecursively();
           QDir().mkdir("tmp");
           qDebug() << "Create dir tmp";

           m_Process = new QProcess;
           connect(m_Process, SIGNAL(readyReadStandardOutput()),
                        this, SLOT(readSubProcess()));

           connect(m_Process, SIGNAL(readyReadStandardError()),
                        this, SLOT(readError()));

           QString command = "bash /home/florianfrank/Documents/Research/Projects/PUFMem/stm_measurement_firmware/FlashTool/Qt/STM32FlashTool/compile_fw_STM32F4.sh " + memory + " 2>&1";
           m_Process->setWorkingDirectory("./tmp");
           m_Process->setProgram("cmake");
           QStringList arguments = {"../../../..", "-DBoardName='stm32f429'", "-DMEMORY_TYPE="+memory+"=1", "-DBoardClass=STM32F4", "-DCPU=cortex-m4", "-DFPUType=hard", "-DFPUSpecification=fpv4-sp-d16", "-Dspecs=rdimon.specs", "-DOS_USE_SEMIHOSTING=1"};
           m_Process->setArguments(arguments);
           m_Process->start();
           m_Process->waitForFinished(30000);

           m_Process->reset();
           m_Process->setArguments(QStringList("-d"));
           m_Process->setProgram("make");

           m_Process->setWorkingDirectory("./tmp");
           m_Process->start();*/

}


void Compilation::readSubProcess()
{
     QByteArray ret = m_Process->readAllStandardOutput();
    QString compileText = QTextCodec::codecForMib(106)->toUnicode(ret);
    setCompileText(compileText);
}

void Compilation::readError()
{
    QString compileText = m_Process->readAllStandardError();
    setCompileText(compileText);
}

QString& Compilation::compileText()
{
    qDebug() << "Get compile TEXT";
    return m_CompileText;
}


void Compilation::setCompileText(QString &compileText)
{
    m_CompileText.append(compileText);
    emit compileTextChanged(m_CompileText);
}
